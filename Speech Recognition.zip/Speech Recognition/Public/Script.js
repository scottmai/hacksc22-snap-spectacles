// -----JS CODE-----
//@input bool gameMode
//import both scenes (game and learn) and enable 
//@input SceneObject game
//@input SceneObject learn

global.behaviorSystem.addCustomTriggerResponse("setGameMode", setGameMode);

var gm = script.gameMode;



function setGameMode(){
    print("test response");
    if(gm){
    //run script for game mode
        
    }
    else{
        //run script for learn mode
        
    }
}


